



test -r ${PREFIX}/fonts/DejaVuSans.ttf
IF %ERRORLEVEL% NEQ 0 exit /B 1
test -r ${PREFIX}/fonts/DejaVuSerif.ttf
IF %ERRORLEVEL% NEQ 0 exit /B 1
test -r ${PREFIX}/fonts/DejaVuSansMono.ttf
IF %ERRORLEVEL% NEQ 0 exit /B 1
test -r ${PREFIX}/etc/fonts/config.d/57-dejavu-sans.conf
IF %ERRORLEVEL% NEQ 0 exit /B 1
test -r ${PREFIX}/etc/fonts/config.d/57-dejavu-sans-mono.conf
IF %ERRORLEVEL% NEQ 0 exit /B 1
test -r ${PREFIX}/etc/fonts/config.d/57-dejavu-serif.conf
IF %ERRORLEVEL% NEQ 0 exit /B 1
exit /B 0
