

set -ex



test -r ${PREFIX}/fonts/DejaVuSans.ttf
test -r ${PREFIX}/fonts/DejaVuSerif.ttf
test -r ${PREFIX}/fonts/DejaVuSansMono.ttf
test -r ${PREFIX}/etc/fonts/config.d/57-dejavu-sans.conf
test -r ${PREFIX}/etc/fonts/config.d/57-dejavu-sans-mono.conf
test -r ${PREFIX}/etc/fonts/config.d/57-dejavu-serif.conf
exit 0
