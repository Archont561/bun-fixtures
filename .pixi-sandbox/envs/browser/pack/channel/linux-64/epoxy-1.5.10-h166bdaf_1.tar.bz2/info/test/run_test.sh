

set -ex



test -f $PREFIX/include/epoxy/common.h
test -f $PREFIX/include/epoxy/egl.h
test -f $PREFIX/include/epoxy/egl_generated.h
test -f $PREFIX/include/epoxy/gl.h
test -f $PREFIX/include/epoxy/gl_generated.h
test -f $PREFIX/include/epoxy/glx.h
test -f $PREFIX/include/epoxy/glx_generated.h
test -f $PREFIX/lib/libepoxy${SHLIB_EXT}
pkg-config --debug --exists epoxy
pkg-config --validate epoxy
exit 0
