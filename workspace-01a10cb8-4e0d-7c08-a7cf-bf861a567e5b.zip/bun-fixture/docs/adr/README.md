# Architecture decision records

Short, immutable records of *why*. Supersede rather than rewrite.

| # | Decision | Status |
|---|----------|--------|
| [0001](./0001-preload-not-bun-plugin.md) | Preload script, not `Bun.plugin()` | accepted |
| [0002](./0002-path-based-directory-scoping.md) | Path-based directory scoping | accepted |
| [0003](./0003-raw-ts-distribution.md) | Ship raw TypeScript | accepted |
| [0004](./0004-smol-toml-for-cli.md) | `smol-toml` for `bunfig.toml` edits | accepted |
| [0005](./0005-explicit-import-no-global-patch.md) | Explicit import, no global monkey-patch | accepted |
| [0006](./0006-use-returns-a-promise.md) | `use` returns a promise | accepted |
| [0007](./0007-file-scope-closes-on-file-switch.md) | File scope closes on file switch | accepted |
| [0008](./0008-no-root-fixtures-file.md) | No repository-root `fixtures.ts` | accepted |
| [0009](./0009-citty-for-the-cli.md) | citty for the CLI | accepted |
| [0010](./0010-monorepo-layout.md) | Monorepo layout | accepted |

Start from [`TEMPLATE.md`](./TEMPLATE.md).
