# Specifications

One numbered spec per component. A spec describes **required behaviour** and how
it is verified; rationale belongs in [`../adr`](../adr), scheduling in
[`../milestones`](../milestones).

| # | Spec | Status | Implementation |
|---|------|--------|----------------|
| [0001](./0001-fixture-engine.md) | Fixture engine — scopes, teardown, DI, params | implemented | `src/plugin.ts` |
| [0002](./0002-discovery-and-merge.md) | Preload discovery + directory merge | implemented | `src/plugin.ts` |
| [0003](./0003-cli-init.md) | CLI `init` | implemented | `src/cli.ts` |
| [0004](./0004-public-api-and-types.md) | Public API + types | implemented | `src/plugin.ts`, `src/types.ts` |
| [0005](./0005-packaging-and-release.md) | Packaging and release | draft | `package.json` |
| [0006](./0006-behavioural-test-suite.md) | Behavioural (Gherkin) test suite | implemented | `features/`, `tests/steps/` |

Start a new one from [`TEMPLATE.md`](./TEMPLATE.md).

Keywords **MUST**, **SHOULD**, **MAY** are used as in RFC 2119.
